<?php

/* Define username and password */
$Username = "Steve";
$Password = "$2y$10$1GmNO63bbKWpaPxcqLaLW.yVmvoxyOD9krWXxn2XAY.QSdbfcARDK";
